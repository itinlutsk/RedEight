/* ── ACTIVE NAV ─────────────────────────────────────────────────────── */
(function () {
  var page = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-desktop a, .mobile-nav-wrap a').forEach(function (a) {
    var href = a.getAttribute('href');
    if (href === page || (page === 'index.html' && href === 'index.html') ||
        (page === '' && href === 'index.html')) {
      a.classList.add('active');
    }
  });
})();

/* ── MOBILE MENU ────────────────────────────────────────────────────── */
var menuToggle = document.getElementById('menuToggle');
var mobileNav  = document.getElementById('mobileNav');
if (menuToggle && mobileNav) {
  menuToggle.addEventListener('click', function () {
    mobileNav.classList.toggle('open');
    menuToggle.innerHTML = mobileNav.classList.contains('open')
      ? '<i class="bi bi-x-lg"></i>'
      : '<i class="bi bi-list"></i>';
  });
}

/* ── ANIMATED COUNTER ───────────────────────────────────────────────── */
function animateCounter(el) {
  var target  = parseInt(el.dataset.target, 10);
  var suffix  = el.dataset.suffix || '';
  var duration = 1500;
  var step    = target / (duration / 16);
  var current = 0;
  var timer = setInterval(function () {
    current += step;
    if (current >= target) { current = target; clearInterval(timer); }
    el.textContent = Math.floor(current) + suffix;
  }, 16);
}

var observed = new Set();
var counterObserver = new IntersectionObserver(function (entries) {
  entries.forEach(function (entry) {
    if (entry.isIntersecting && !observed.has(entry.target)) {
      observed.add(entry.target);
      animateCounter(entry.target);
    }
  });
}, { threshold: 0.3 });

document.querySelectorAll('[data-counter]').forEach(function (el) {
  counterObserver.observe(el);
});

/* ── HERO SLIDER ────────────────────────────────────────────────────── */
var slides = document.querySelectorAll('.hero-slide');
var dots   = document.querySelectorAll('.hero-dot');
var current = 0;

function goToSlide(n) {
  slides[current].classList.remove('active');
  if (dots[current]) dots[current].classList.remove('active');
  current = n;
  slides[current].classList.add('active');
  if (dots[current]) dots[current].classList.add('active');
}

if (slides.length > 1) {
  dots.forEach(function (dot, i) {
    dot.addEventListener('click', function () { goToSlide(i); });
  });
  setInterval(function () { goToSlide((current + 1) % slides.length); }, 5000);
}

/* ── PORTFOLIO FILTER ───────────────────────────────────────────────── */
var filterBtns = document.querySelectorAll('[data-filter]');
filterBtns.forEach(function (btn) {
  btn.addEventListener('click', function () {
    filterBtns.forEach(function (b) { b.classList.remove('active'); });
    btn.classList.add('active');
    var tag = btn.dataset.filter;
    document.querySelectorAll('[data-tag]').forEach(function (card) {
      var col = card.closest('.portfolio-col');
      if (!col) return;
      col.style.display = (tag === 'Усі' || card.dataset.tag === tag) ? '' : 'none';
    });
  });
});

/* ── FAQ ACCORDION ──────────────────────────────────────────────────── */
document.querySelectorAll('.faq-question').forEach(function (btn) {
  btn.addEventListener('click', function () {
    var item = btn.closest('.faq-item');
    var isOpen = item.classList.contains('open');
    document.querySelectorAll('.faq-item').forEach(function (i) { i.classList.remove('open'); });
    if (!isOpen) item.classList.add('open');
  });
});

/* ── CONTACT FORM ───────────────────────────────────────────────────── */
var contactForm = document.getElementById('contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var valid = true;

    var name  = document.getElementById('inputName');
    var phone = document.getElementById('inputPhone');
    var nameErr  = document.getElementById('nameErr');
    var phoneErr = document.getElementById('phoneErr');

    if (nameErr)  nameErr.classList.remove('show');
    if (phoneErr) phoneErr.classList.remove('show');

    if (name && name.value.trim().length < 2) {
      if (nameErr) nameErr.classList.add('show');
      valid = false;
    }
    if (phone && phone.value.replace(/\D/g, '').length < 10) {
      if (phoneErr) phoneErr.classList.add('show');
      valid = false;
    }

    if (valid) {
      contactForm.reset();
      document.querySelectorAll('.type-btn').forEach(function (b) { b.classList.remove('active'); });
      showToast('Дякуємо!', 'Ми зв\'яжемося з вами найближчим часом.');
    }
  });

  /* type buttons */
  document.querySelectorAll('.type-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.type-btn').forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
    });
  });
}

/* ── TOAST ──────────────────────────────────────────────────────────── */
function showToast(title, desc) {
  var container = document.getElementById('toastContainer');
  if (!container) return;
  var el = document.createElement('div');
  el.className = 'toast-msg';
  el.innerHTML = '<strong>' + title + '</strong>' + (desc || '');
  container.appendChild(el);
  setTimeout(function () { el.remove(); }, 4000);
}
