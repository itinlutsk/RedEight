/* ── HEADER: sticky + mobile menu ───────────────────────────────────── */
(function () {
  var header   = document.getElementById('vdHeader');
  var burger   = document.getElementById('vdBurger');
  var mobileNav = document.getElementById('vdMobileNav');

  if (header) {
    window.addEventListener('scroll', function () {
      header.classList.toggle('scrolled', window.scrollY > 40);
    }, { passive: true });
  }

  if (burger && mobileNav) {
    burger.addEventListener('click', function () {
      mobileNav.classList.toggle('open');
      burger.innerHTML = mobileNav.classList.contains('open')
        ? '<i class="bi bi-x-lg"></i>'
        : '<i class="bi bi-list"></i>';
    });
  }
})();

/* ── HERO Ken-Burns on load ──────────────────────────────────────────── */
(function () {
  var hero = document.querySelector('.vd-hero');
  if (hero) {
    setTimeout(function () { hero.classList.add('in-view'); }, 100);
  }
})();

/* ── SCROLL ANIMATIONS (IntersectionObserver) ───────────────────────── */
(function () {
  var els = document.querySelectorAll('.animate-on-scroll');
  if (!els.length) return;

  var obs = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  els.forEach(function (el) { obs.observe(el); });
})();

/* ── SMOOTH SCROLL TO ANCHORS ────────────────────────────────────────── */
document.querySelectorAll('a[href^="#"]').forEach(function (link) {
  link.addEventListener('click', function (e) {
    var target = document.querySelector(link.getAttribute('href'));
    if (target) {
      e.preventDefault();
      var offset = 80;
      var top = target.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top: top, behavior: 'smooth' });
    }
  });
});

/* ── ACTIVE NAV ON SCROLL ────────────────────────────────────────────── */
(function () {
  var sections = document.querySelectorAll('section[id], div[id]');
  var navLinks = document.querySelectorAll('.vd-nav a, .vd-mobile-nav a');

  function setActive() {
    var scrollY = window.scrollY + 120;
    sections.forEach(function (sec) {
      if (sec.offsetTop <= scrollY && sec.offsetTop + sec.offsetHeight > scrollY) {
        navLinks.forEach(function (link) {
          link.classList.remove('active');
          if (link.getAttribute('href') === '#' + sec.id) {
            link.classList.add('active');
          }
        });
      }
    });
  }

  window.addEventListener('scroll', setActive, { passive: true });
})();

/* ── GALLERY LIGHTBOX ────────────────────────────────────────────────── */
(function () {
  var galleryImages = [];
  var currentIndex  = 0;

  var lightbox  = document.getElementById('vdLightbox');
  var lbImg     = document.getElementById('lbImg');
  var lbCounter = document.getElementById('lbCounter');
  var lbClose   = document.getElementById('lbClose');
  var lbPrev    = document.getElementById('lbPrev');
  var lbNext    = document.getElementById('lbNext');

  if (!lightbox) return;

  /* Collect gallery items */
  document.querySelectorAll('.vd-gallery-img').forEach(function (img) {
    galleryImages.push({ src: img.src, alt: img.alt });
  });

  function showSlide(index) {
    currentIndex = (index + galleryImages.length) % galleryImages.length;
    lbImg.src    = galleryImages[currentIndex].src;
    lbImg.alt    = galleryImages[currentIndex].alt;
    if (lbCounter) {
      lbCounter.textContent = (currentIndex + 1) + ' / ' + galleryImages.length;
    }
  }

  function openLightbox(index) {
    showSlide(index);
    lightbox.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeLightbox() {
    lightbox.classList.remove('open');
    document.body.style.overflow = '';
  }

  /* Open on image click (whole wrapper is clickable) */
  document.querySelectorAll('.vd-gallery-wide, .vd-gallery-small').forEach(function (wrap) {
    wrap.addEventListener('click', function () {
      var img = wrap.querySelector('.vd-gallery-img');
      if (!img) return;
      var idx = parseInt(img.dataset.index, 10) || 0;
      openLightbox(idx);
    });
  });

  lbClose.addEventListener('click', closeLightbox);
  lbPrev  && lbPrev.addEventListener('click', function () { showSlide(currentIndex - 1); });
  lbNext  && lbNext.addEventListener('click', function () { showSlide(currentIndex + 1); });

  /* Close on backdrop click */
  lightbox.addEventListener('click', function (e) {
    if (e.target === lightbox) closeLightbox();
  });

  /* Keyboard navigation */
  document.addEventListener('keydown', function (e) {
    if (!lightbox.classList.contains('open')) return;
    if (e.key === 'Escape')     closeLightbox();
    if (e.key === 'ArrowLeft')  showSlide(currentIndex - 1);
    if (e.key === 'ArrowRight') showSlide(currentIndex + 1);
  });

  /* Touch swipe */
  var touchStartX = 0;
  lightbox.addEventListener('touchstart', function (e) {
    touchStartX = e.touches[0].clientX;
  }, { passive: true });
  lightbox.addEventListener('touchend', function (e) {
    var dx = e.changedTouches[0].clientX - touchStartX;
    if (Math.abs(dx) > 50) {
      dx < 0 ? showSlide(currentIndex + 1) : showSlide(currentIndex - 1);
    }
  }, { passive: true });
})();

/* ── TOAST ───────────────────────────────────────────────────────────── */
function showToast(title, desc) {
  var container = document.getElementById('toastContainer');
  if (!container) return;
  var el = document.createElement('div');
  el.className = 'vd-toast';
  el.innerHTML = (title ? '<strong>' + title + '</strong>' : '') + (desc || '');
  container.appendChild(el);
  setTimeout(function () { el.remove(); }, 4000);
}
